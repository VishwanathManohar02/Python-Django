# -*- coding: utf-8 -*-

from Book import Book
from Catalog import Catalog
from BookReserve import BookReserve


# -*- coding: utf-8 -*-
# -*- coding: utf-8 -*-
class User:
    def __init__(self, name, location, age, aadhar_id):
        self.name = name
        self.location = location
        self.age = age
        self.aadhar_id = aadhar_id
        

class Member(User):
    def __init__(self,name, location, age, aadhar_id,student_id):
        super().__init__(name, location, age, aadhar_id)
        self.student_id = student_id
        self.books_in_list = {}
        
    def __repr__(self):
        return self.name + ' ' + self.location + ' ' + self.student_id
    
    #assume name is unique
    def issueBook(self,name,isbn,days=10):
        if len(self.books_in_list)== 5:
            return "You cannot take more that 5 books"
        if (name,isbn) not in self.books_in_list:
            if (name,isbn) in BookReserve.books_issued_reserved_list:
                if BookReserve.books_issued_reserved_list[name,isbn] == 'reserved':
                    return 'This book is already reserved by other user, please try with other isbn'
        for book in Catalog.books:
            if name == book.name:
                for book_item in book.book_item:
                    if book_item.isbn == isbn:
                        book.total_count -= 1
                        self.books_in_list[book.name,isbn] = ['issued',days]
                        Catalog.books_by_members[self,name,isbn] = ['issued',days]
                        
    def reserveBook(self,name,isbn,days=2):
        if days > 2:
            return "You cannot reserve more than two days"
        else:
            b = BookReserve(name,isbn)
            b.reserveBook(name,isbn,days)
            self.books_in_list[name,isbn] = ['reserved',days]
            Catalog.books_by_members[self,name,isbn] = ['issued',days]
    
    #assume name is unique
    def returnBook(self,name,isbn,days):
        for book in Catalog.books:
            if name == book.name:
                for book_item in book.book_item:
                    if book_item.isbn == isbn:
                        book.total_count += 1
                        self.books_in_list[book.name,isbn] = ['returned',days]
                        del Catalog.books_by_members[self,name,isbn]
                        
        
class Librarian(User):
    def __init__(self,name, location, age, aadhar_id,emp_id):
        super().__init__(name, location, age, aadhar_id)
        self.emp_id = emp_id
        
    def __repr__(self):
        return self.name + self.location + self.emp_id
    
    def addBook(self,name,author,publish_date,pages):
        b = Book(name,author,publish_date,pages)
        Catalog.books.append(b)
        return b
    
    def removeBook(self,name):
        for book in Catalog.books:
            if name == book.name:
                Catalog.books.remove(name)

    
        