# -*- coding: utf-8 -*-
"""
Created on Fri Jan 10 01:00:22 2020

@author: Vishwa
"""

class LibraryCard:
    
    @classmethod
    def displayLibraryCard(cls,user):
        print('Name :',user.name)
        print('Location :',user.location)
        print('Age :',user.age)
        print('Aadhar_id :',user.aadhar_id)
        if 'student_id' in user.__dict__:
            print('Student_id :',user.student_id)
        elif 'emp_id' in user.__dict__:
            print('emp_id :',user.emp_id)