# -*- coding: utf-8 -*-
"""
Created on Fri Jan 10 00:58:51 2020

@author: Vishwa
"""


class BillingAndFine:
    def __init__(self):
        self.amount_per_day = 10
        self.fine_amount_per_day = 20
        self.bill_amount = 0
        self.extra_days = 0
        self.normal_days_allowed = 0
        
    def billAmount(self,user):
#         sum_amount = sum(list(map(lambda x : x[1]*self.amount_per_day , filter(lambda x : x[0] == 'returned',user.books_in_list.values()))))
#         return "The amount including all fines is {}".format(sum_amount)  
        for status_list in user.books_in_list.values():
            if status_list[0] == 'returned':
                if status_list[1] > 10:
                    self.bill_amount = self.bill_amount + (self.amount_per_day*10) + (self.fine_amount_per_day*(status_list[1]-10))
                    self.extra_days = self.extra_days + status_list[1]-10
                    self.normal_days_allowed = self.normal_days_allowed + 10
                else:
                    self.bill_amount = self.bill_amount + (self.amount_per_day*status_list[1])
                    self.normal_days_allowed = self.normal_days_allowed + status_list[1]
        print("The bill amount without any fine is {}".format(self.amount_per_day*self.normal_days_allowed))
        print("The fine amount for extra days is {}".format(self.fine_amount_per_day*self.extra_days))
        return "The Total bill amount is {}".format(self.bill_amount)   