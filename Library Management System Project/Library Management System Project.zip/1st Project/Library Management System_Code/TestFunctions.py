# -*- coding: utf-8 -*-
from Book import Book
from Catalog import Catalog
from User import Member, Librarian
from BillingAndFine import BillingAndFine
from LibraryCard import LibraryCard
from BookReserve import BookReserve
from SearchSupport import SearchSupport

# Test Functions and object creation

b1 = Book('Shoe Dog','Phil Knight', '2015',312)
b1.addBookItem('123hg','H1B2')
b1.addBookItem('124hg','H1B3')

# b1.printBook()

catalog = Catalog()

b = catalog.addBook('Shoe Dog','Phil Knight', '2015',312)
catalog.addBookItem(b, '123hg','H1B2')
catalog.addBookItem(b, '124hg','H1B4')
catalog.addBookItem(b, '125hg','H1B5')

b = catalog.addBook('Moonwalking with Einstien','J Foer', '2017',318)
catalog.addBookItem(b, '463hg','K1B2')

m1 = Member("Vish","Bangalore",23,'asljlkj22','std1233')

librarian = Librarian("Awantik","Bangalore",34,'asljlkj22','zeke101') 

# print (m1)
# print (librarian)

# print(catalog.books)
# catalog.displayAllBooks()
# m1.reserveBook('Shoe Dog','123hg')
# m1.issueBook('Shoe Dog','123hg')
# m1.returnBook('Shoe Dog','123hg',12)
# m1.reserveBook('Shoe Dog','124hg')
# m1.issueBook('Shoe Dog','124hg')
# print(BookReserve.books_issued_reserved_list)
# print(m1.books_in_list)


# Library member should be able to search books by their title, author.
catalog.searchByName('Moonwalking with Einstien')

# Each book will have unique identification number & location of the book where it’s located.
catalog.displayAllBooks()

# More than one copy of book can be there. Library member should be able to reserve a book, return a book.
m1.issueBook('Moonwalking with Einstien','463hg')
m1.reserveBook('Shoe Dog','123hg')
m1.issueBook('Shoe Dog','123hg')
m1.returnBook('Shoe Dog','123hg',12)
m1.reserveBook('Shoe Dog','124hg')
m1.issueBook('Shoe Dog','124hg')
print(BookReserve.books_issued_reserved_list)
print(m1.books_in_list)

# Library system should be able to retrieve information like who took a book & when it will be returned. Max num of books (5) & max days (10) allowed will be set in system.
Catalog.books_in_members_list()

# System to collect fines if return date exceeds.
bill = BillingAndFine()
bill.billAmount(m1)

# Display Library Card
LibraryCard.displayLibraryCard(m1)

# Search using Search Support
s = SearchSupport()
print(s)
print(s.searchByAuthor('Phil Knight'))