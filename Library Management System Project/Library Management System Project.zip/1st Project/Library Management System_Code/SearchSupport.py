# -*- coding: utf-8 -*-
"""
Created on Fri Jan 10 01:01:24 2020

@author: Vishwa
"""

from Catalog import Catalog


class SearchSupport(Catalog):
    
    def __str__(self):
        return "Hello, select either searchByName or searchByAuthor to find the book"