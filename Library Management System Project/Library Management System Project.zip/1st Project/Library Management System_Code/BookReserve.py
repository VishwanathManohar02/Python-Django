# -*- coding: utf-8 -*-
"""
Created on Fri Jan 10 01:00:58 2020

@author: Vishwa
"""
from Catalog import Catalog

class BookReserve:
    
    books_issued_reserved_list = {}
    def __init__(self,name,isbn):
        self.name = name
        self.isbn = isbn
    
    def reserveBook(self,name,isbn,days):
        for book in Catalog.books:
            if book.name == name:
                for book_item in book.book_item:
                    if book_item.isbn == isbn:
                        BookReserve.books_issued_reserved_list[book.name,isbn] = 'reserved'
                        return BookReserve.books_issued_reserved_list
                else:
                    print("The book name with this {} isbn is not available in our libraray".format(isbn))
        else:
            print("The book name you are searching for is not available in our library")
