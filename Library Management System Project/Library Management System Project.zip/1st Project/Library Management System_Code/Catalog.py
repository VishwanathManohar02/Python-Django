# -*- coding: utf-8 -*-
from Book import Book

#First Book is file & second is Class

class Catalog:
    
    books = []
    books_by_members = {}
    
    def __init__(self):
        self.different_book_count = 0
        
    #Only available to admin
    def addBook(self,name,author,publish_date,pages):
        b = Book(name,author,publish_date,pages)
        self.different_book_count += 1
        Catalog.books.append(b)
        return b
    
    #Only available to admin
    def addBookItem(self,book,isbn,rack):
        book.addBookItem(isbn, rack)
        
    def searchByName(self,name):
        for book in Catalog.books:
            if book.name == name:
                return "The Book you were finding is {} and written by {} and available qty is {}".format(book.name,book.author,book.total_count)
        else:
            return "The Book you are trying to find out is not available"
    
    def searchByAuthor(self,author):
        for book in Catalog.books:
            if book.author == author:
                return "The Book written by {} is {} and available qty is {}".format(author,book.name,book.total_count)
        else:
            return "The Book this author is not available"
       
    def displayAllBooks(self):
#         print ('Different Book Count',self.different_book_count)
        c = 0
        for book in Catalog.books:
            c += book.total_count
            book.printBook()
        
        print ('Total Book Count',c)
        
    @classmethod
    def books_in_members_list(cls):
        for books in cls.books_by_members.items():
            print(books)
